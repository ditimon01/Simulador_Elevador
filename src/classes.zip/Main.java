
import estruturas.ListaDupla;

public class Main {
    public static void main(String[] args) {

        ListaDupla lista = new ListaDupla();

        System.out.println(lista.add("cachorro",0));
        System.out.println(lista.add("gato",1));

        lista.printarLista();




    }
}
