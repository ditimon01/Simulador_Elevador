package classes;

import estruturas.ListaEstatica;

public class Predio extends Serializacao {

    private ListaEstatica<Andar> andares;
    private CentralDeControle centralDeControle;


 public Predio(int numeroAndares, int numeroElevadores){
     this.andares = new ListaEstatica(numeroAndares);
     for (int i = 0; i < numeroAndares; i++){
         andares.add(new Andar(i),i);
     }
     this.centralDeControle = new CentralDeControle(numeroElevadores);

 }

    @Override
    public void atualizar (int MinutosSimulados){
       centralDeControle.atualizar(MinutosSimulados);
    }

    public CentralDeControle getCentralDeControle() { return centralDeControle; }
    public ListaEstatica<Andar> getAndares() { return andares; }

}
