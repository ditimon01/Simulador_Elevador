package classes;

import estruturas.ListaEstatica;

public class CentralDeControle extends Serializacao  {
    private ListaEstatica<Elevador> elevadores;

    public CentralDeControle(int numeroElevadores) {
        this.elevadores = new ListaEstatica<Elevador>(numeroElevadores);
        for (int i = 0; i < numeroElevadores; i++) {
            elevadores.add(new Elevador(i), i);
        }
    }

    @Override
    public void atualizar(int minutosSimulados) {
        for(int i = 0; i < elevadores.getTamanho(); i++){
            elevadores.getVetor()[i].atualizar(minutosSimulados);
        }
    }

    public ListaEstatica<Elevador> getElevadores() { return elevadores; }

}
