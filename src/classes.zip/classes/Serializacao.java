package classes;

import java.io.Serializable;

public abstract class Serializacao implements Serializable{
    public abstract void atualizar(int minutoSimulado);

    }
