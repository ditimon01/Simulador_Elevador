package classes;

import estruturas.ListaDinamica;


public class Elevador extends Serializacao {

    private int numerodoElevador;
    private int andarAtual;
    private int destino;
    private ListaDinamica<Pessoa> pessoasDentro;
    private final int CAPACIDADE_MAXIMA = 10;
    private EstadoElevador estado;

    //definir possíveis estados do elevador
    public enum EstadoElevador {
        PARADO, SUBINDO, DESCENDO
    }


    public Elevador(int numero) {
        this.numerodoElevador = numero;
        this.andarAtual = 0;
        this.destino = 0;
        this.pessoasDentro = new ListaDinamica<>();
        this.estado = EstadoElevador.PARADO;
    }

    @Override
    public void atualizar(int MinutosSimulados){
        System.out.println("Elevador " + numerodoElevador + " no andar " + andarAtual + " no minuto " + MinutosSimulados + " - Estado: " + estado);

        if(andarAtual < destino){
            estado = EstadoElevador.SUBINDO;
            andarAtual++;
        }else if(andarAtual > destino){
            estado = EstadoElevador.DESCENDO;
            andarAtual--;
        }else{
            estado = EstadoElevador.PARADO;
            /// //////////
        }
    }

    public void adicionarPessoa(Pessoa p){
        if(pessoasDentro.tamanho() < CAPACIDADE_MAXIMA){
            pessoasDentro.add(p, pessoasDentro.tamanho() + 1); //editar após adicionar fila de prioridade
            p.entrarElevador();
            System.out.println("Pessoa " + p.getId() + " entrou no elevador " + numerodoElevador);
        }
    }


    public void setDestino(int destino) {
        this.destino = destino;
    }


}
